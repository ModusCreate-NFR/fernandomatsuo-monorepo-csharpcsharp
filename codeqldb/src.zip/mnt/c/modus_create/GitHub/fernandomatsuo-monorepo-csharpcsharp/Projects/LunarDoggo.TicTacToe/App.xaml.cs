using System.Windows;

namespace TicTacToe
{
    /// <summary>
    /// Interactionlogic for "App.xaml"
    /// </summary>
    public partial class App : Application
    {
        //In this class you could override multiple methods to customize your application
    }
}
